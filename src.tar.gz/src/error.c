const int vdisk_ENODISK  = -1;
const int vdisk_EACCESS  = -2;
const int vdisk_ENOEXIST = -3;
const int vdisk_EEXCEED  = -4;
const int vdisk_ESECTOR  = -5;
